package com.robotloop.myapplication;

import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;

import io.reactivex.Observable;
import io.reactivex.Scheduler;
import io.reactivex.Single;
import io.reactivex.SingleObserver;
import io.reactivex.SingleSource;
import io.reactivex.disposables.Disposable;
import io.reactivex.internal.operators.single.SingleLift;
import io.reactivex.schedulers.Schedulers;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(onDeviceResponse);

        findViewById(R.id.buttonTest).setOnClickListener(onBLESent);
        test();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    private SingleObserver bleObserver;
    private SingleObserver deviceObserver;

    private View.OnClickListener onDeviceResponse = new View.OnClickListener() {
        @Override
        public void onClick(View view) {
            Log.v("RxJava", "Device success");
            deviceObserver.onSuccess("");
        }
    };

    private View.OnClickListener onBLESent = new View.OnClickListener() {
        @Override
        public void onClick(View view) {
            Log.v("RxJava", "BLE success");
            bleObserver.onSuccess("");
        }
    };
    public SingleSource sendBleData(byte[] data){
        return new SingleSource() {
            @Override
            public void subscribe(SingleObserver observer) {
                bleObserver = observer;
                Log.v("RxJava", "BLE Data Send");
                //Send data here

            }
        };
    }

    boolean isLarge = false;

    public SingleSource sendPacketToDevice(final byte[] cmd){
        return new SingleSource() {
            @Override
            public void subscribe(SingleObserver observer) {
                deviceObserver = observer;

                byte[] a;
                byte[] a1 = {1};
                byte[] a4 = {1, 2, 3, 4};
                if (isLarge) {
                    a = a4;
                    Log.v("RxJava", "Large packet");
                } else {
                    a = a1;
                    Log.v("RxJava", "Small packet");
                }

                isLarge = !isLarge;

                Observable.fromArray(a).subscribeOn(Schedulers.io()).flatMapSingle(d -> sendBleData(a1)).subscribe(ret -> {}, error -> observer.onError(new Throwable()));
//                Single o = Single.just("").subscribeOn(Schedulers.io());
//                for (int i = 0; i < a.length; i++) {
//                    o = o.flatMap(data -> sendBleData(a1));
//                }
//                o.subscribe(ret -> {
//                }, error -> observer.onError(new Throwable()));

            }
        };
    }


    public SingleSource SendAllData(byte[] d){
        Log.v("RxJava", "Send all");
        byte[] pageAddr = {1};
        byte[] pagedata={1};

        Single o = Single.just("").subscribeOn(Schedulers.io());
        for (int i = 0; i < 3; i++){
            //pageAddr = ...
            //pageData = ...
            o = o.flatMap(s ->sendPacketToDevice(pageAddr)).flatMap(s -> sendPacketToDevice(pagedata));
        };

        return o;
    }

    public SingleSource sendPage(byte[] d){
        byte[] pageAddr = {1};
        byte[] pagedata={1};
        return Single.just("").flatMap(s -> sendPacketToDevice(pageAddr)).flatMap(s -> sendPacketToDevice(pagedata));
    }

    public void test(){

        byte[] cmd = {50};

        Single.just("").subscribeOn(Schedulers.io())
                .flatMap(d -> sendBleData(cmd))
                .flatMap(d -> sendPacketToDevice(cmd))
                .flatMap(d -> sendPacketToDevice(cmd))
                .flatMap(d -> sendPacketToDevice(cmd))
                .flatMap(d -> SendAllData(cmd))
                .subscribe(new SingleObserver() {
                    @Override
                    public void onSubscribe(Disposable d) {

                    }

                    @Override
                    public void onSuccess(Object o) {
                        Log.v("RxJava", "Done all!!!");
                    }

                    @Override
                    public void onError(Throwable e) {

                    }
                });
       }


}